#ifndef __HEAD_H__
#define __HEAD_H__

#include <iostream>
#include <string>

#include <arpa/inet.h>
#include <event.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/epoll.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#endif //__HEAD_H__


