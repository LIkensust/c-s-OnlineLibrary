make
./CreateJson
./create_file.sh -f 1000 3

