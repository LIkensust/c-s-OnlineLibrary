#!/bin/bash
rm -rf ./books
rm -f ./booklist
rm -f ./hash_config.cfg
rm -f ./text.json
make clean
